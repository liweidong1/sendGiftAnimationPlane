//
//  ViewController.m
//  Feiji
//
//  Created by liweidong on 17/6/8.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import "ViewController.h"
#import "NHHeader.h"
#import "NHCarViews.h"
#import "NHPlaneViews.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

}
- (IBAction)click:(id)sender {
    NHFighterView *fighter = [NHFighterView loadFighterViewWithPoint:CGPointMake(10, 100)];
    //fighter.curveControlAndEndPoints 用法同carView一样
    [fighter addAnimationsMoveToPoint:CGPointMake(self.view.bounds.size.width, 60) endPoint:CGPointMake( -500, 600)];
    [self.view addSubview:fighter];


}



@end
